.. _getting_started:

Quickstart
========================

Some examples of using OpenID, Admin and UMA integration.

For more details, see :ref:`api`.

.. toctree::
    :maxdepth: 2

    modules/openid_client
    modules/admin
    modules/uma
    modules/async
