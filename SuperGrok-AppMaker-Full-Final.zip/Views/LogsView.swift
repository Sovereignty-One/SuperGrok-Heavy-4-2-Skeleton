import SwiftUI
struct LogsView: View { var body: some View { Text("Live Logs") } }
